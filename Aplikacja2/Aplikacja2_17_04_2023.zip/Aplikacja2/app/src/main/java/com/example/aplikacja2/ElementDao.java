package com.example.aplikacja2;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

//adnotacja określająca, że interfejs opisuje DAO
@Dao
public interface ElementDao {
    //adnotacja określająca, że metoda wstawia element do bazy
    //w przypadku konfliktu operacja będzie przerwana
    @Insert(onConflict = OnConflictStrategy.ABORT)
    void insert(Phone phone);

    //adnotacja pozwalająca na wykonanie dowolnego polecenia np. skasowania wszystkich elementów
    @Query("DELETE FROM Phones")
    void deleteAll();

    @Delete
    void delete(Phone phone);

    //metoda zwraca listę elementów opakowaną w pojemnik live data pozwalający na odbieranie
    //powiadomień o zmianie danych. Room wykonuje zapytanie w innym wątku
    @Query("SELECT * FROM Phones ORDER BY Model ASC")
    LiveData<List<Phone>> getAlphabetizedElements();

    @Update
    void update(Phone phone);
}
