package com.example.aplikacja2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PhoneListAdapter extends RecyclerView.Adapter<PhoneListAdapter.PhoneViewHolder>{
    private final LayoutInflater mLayoutInflater;
    private List<Phone> mPhoneList;
    public static final String MANUFACTURER_KEY = "manufacturerData";
    public static final String MODEL_KEY = "modelData";
    public static final String VERSION_KEY = "versionData";
    public static final String WEBSITE_KEY = "websiteData";
    public static final String ID_KEY = "idData";

    public PhoneListAdapter(Context context) {
        mLayoutInflater = LayoutInflater.from(context);
        this.mPhoneList = null;
    }

    @NonNull
    @Override
    public PhoneViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = mLayoutInflater.inflate(R.layout.phone_row, parent, false);
        return new PhoneViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull PhoneViewHolder holder, int position) {
        Phone phone = mPhoneList.get(position);
        holder.model.setText(phone.getModel());
        holder.manufacturer.setText(phone.getManufacturer());
        holder.position = holder.getAdapterPosition();
    }

    @Override
    public int getItemCount() {
        //w momencie tworzenia obiektu adaptera lista może nie
        //być dostępna
        if (mPhoneList != null)
            return mPhoneList.size();
        return 0;
    }

    public Phone getPhone(int position){
        return mPhoneList.get(position);
    }

    public void setElementList(List<Phone> phoneList) {
        this.mPhoneList = phoneList;
        notifyDataSetChanged();
    }


    public class PhoneViewHolder extends RecyclerView.ViewHolder{
        TextView model;
        TextView manufacturer;
        int position;
        LinearLayout row;
        private final Context context;

        public PhoneViewHolder(@NonNull View itemView) {
            super(itemView);
            model = itemView.findViewById(R.id.modelRow);
            manufacturer = itemView.findViewById(R.id.maufacturerRow);

            row = itemView.findViewById(R.id.row);
            context = itemView.getContext();

            row.setOnClickListener(view -> {
                final Intent intent;
                intent = new Intent(context, UpdateActivity.class);
                intent.putExtra(MANUFACTURER_KEY,manufacturer.getText().toString());
                intent.putExtra(MODEL_KEY,model.getText().toString());
                intent.putExtra(ID_KEY,mPhoneList.get(position).getId());
                intent.putExtra(WEBSITE_KEY,mPhoneList.get(position).getWebsite());
                intent.putExtra(VERSION_KEY,mPhoneList.get(position).getVersion());
                context.startActivity(intent);
            });
        }


    }
}
